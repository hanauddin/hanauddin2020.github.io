/*

The Game Project 4 - Side scrolling

Week 6

*/

var gameChar_x;
var gameChar_y;
var floorPos_y;
var isLeft;
var isRight;
var scrollPos;

var clouds
var mountains;
var trees;
var houseXs;

function setup()
{
    createCanvas(1024, 576);
    floorPos_y = height * 3/4;
    gameChar_x = width/2;
    gameChar_y = floorPos_y;

    // Boolean variables to control the movement of the game character.
    isLeft = false;
    isRight = false;

    // Variable to control the background scrolling.
    scrollPos = 0;

    // Initialise arrays of scenery objects.
    
    houseXs=[-130,100,485,840];
    
    
    clouds=[{x_pos: -50, y_pos:-30},
            {x_pos:+320,y_pos:-30},
            {x_pos:+680, y_pos:-30}];

    mountains=[{x_pos:0, height: 0},
               {x_pos:0, height:0},
               {x_pos:0, height:0},
               {x_pos:200, height:0}];
    
    trees=[{x_pos:0, height: 0},
           {x_pos:0, height:0},
           {x_pos:0, height:0},
           {x_pos:0, height:0}];

}

function draw()
{
    background(100, 155, 255); //fill the sky blue

    noStroke();
    fill(0, 155, 0);
    rect(0, floorPos_y, width, height/4); //draw some green ground

    // Draw clouds.
    push();
    translate(scrollPos*0.20);
   for(var i = 0; i < clouds.length; i++)

    
    {
    fill(255);
    ellipse(clouds[i].x_pos+160, clouds[i].y_pos+100, 70,60);
    ellipse(clouds[i].x_pos+225, clouds[i].y_pos+100,75,60);
    ellipse( clouds[i].x_pos+270, clouds[i].y_pos+100, 60, 50);
    ellipse(clouds[i].x_pos+115,clouds[i].y_pos+100, 55, 45);
    ellipse(clouds[i].x_pos+195, clouds[i].y_pos+70, 41, 35);
    }
    pop();
    
    // Draw mountains.
    push();
    translate(scrollPos,0);
     for(var i = 0; i < mountains.length; i++)
         
    {   
    fill(102, 51,0);
    triangle ( mountains[i].x_pos+410, mountains[i].height+435, 680, 435, 550, 130);
    triangle ( mountains[i].x_pos+300, mountains[i].height+435, 440, 435, 410, 200);
    triangle ( mountains[i].x_pos+600, mountains[i].height+435, 590, 435, 660, 250);
    }
    pop();
   // instead of x and y values, use "mountains[i].x_pos" and "mountains[i].height" (like in the cloud one) 
    
    // Draw trees.
    push();
    translate(scrollPos,0);
    for(var i = 0; i < trees.length; i++)
        
    { 
    fill(102, 51, 0);
    rect( 1090, 200, 40, 285);
    rect( 1340, 250, 40, 240);
    fill ( 0, 204,0);
    ellipse( trees[i].x_pos+1105,trees[i].height+190, 125 ,125);
    ellipse( trees[i].x_pos+1355,trees[i].height+250, 115 ,125);
    }
    pop();

    // Draw houses.
    push();
    translate(scrollPos,0);
    for(var i = 0; i < houseXs.length; i++)
    {
        
    fill(204, 102,0);
    rect( houseXs[i]+37, 315, 140, 120);
    
    fill ( 51, 51, 255);
    rect( houseXs[i]+45, 320, 45, 40);
    rect ( houseXs[i]+125, 320, 45, 40);
    rect ( houseXs[i]+79, 375, 55, 60);
    triangle(houseXs[i]+35, 315, houseXs[i]+178, 315, houseXs[i]+115, 260);
    }
    pop();

    // Draw the game character.

      
      fill(255,0,0);
      rect(gameChar_x - 15, gameChar_y - 55, 30, 50);
      fill(255,150,150);
      ellipse(gameChar_x, gameChar_y - 55,40, 40);
      fill(0);
      rect(gameChar_x - 16, gameChar_y - 10, 10, 10);
      rect(gameChar_x + 6, gameChar_y - 10, 10, 10);
     

   
    
    // THIS IS THE CODE WHICH MOVES YOUR CHARACTER
    
    if(isLeft)
    {
        if(gameChar_x > width * 0.2)
        {
            gameChar_x -= 5;
        }
        else
        {
            scrollPos += 5;
        }
    }

    if(isRight)
    {
        if(gameChar_x < width * 0.8)
        {
            gameChar_x  += 5;
        }
        else
        {
            scrollPos -= 5; // negative for moving against the background
        }

    }

}
function keyPressed()
{

    if(key == "A" || keyCode == 37)
    {
        isLeft = true;
    }

    if(key == "D" || keyCode == 39)
    {
        isRight = true;
    }

}

function keyReleased()
{
    if(key == "A" || keyCode == 37)
    {
        isLeft = false;
    }

    if(key == "D" || keyCode == 39)
    {
        isRight = false;
    }
}
